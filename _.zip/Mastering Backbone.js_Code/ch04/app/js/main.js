var App = require('./app');

App.start();
